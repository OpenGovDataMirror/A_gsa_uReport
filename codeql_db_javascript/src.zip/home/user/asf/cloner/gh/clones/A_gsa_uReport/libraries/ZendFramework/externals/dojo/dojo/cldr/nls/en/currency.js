// generated from ldml/main/*.xml, xpath: ldml/numbers/currencies
({
	AUD_displayName:"Australian Dollar",
	CAD_displayName:"Canadian Dollar",
	CHF_displayName:"Swiss Franc",
	CNY_displayName:"Chinese Yuan Renminbi",
	EUR_displayName:"Euro",
	GBP_displayName:"British Pound Sterling",
	HKD_displayName:"Hong Kong Dollar",
	JPY_displayName:"Japanese Yen",
	JPY_symbol:"¥",
	USD_displayName:"US Dollar",
	USD_symbol:"$"
})
                 