({
		previousMessage: "Предыдущие варианты",
		nextMessage: "Следующие варианты"
})
