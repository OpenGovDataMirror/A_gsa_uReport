dojo.provide("dijit._tree.dndSource");
dojo.require("dijit.tree.dndSource");

// TODO: remove this file in 2.0
dojo.deprecated("dijit._tree.dndSource has been moved to dijit.tree.dndSource, use that instead", "", "2.0");

dijit._tree.dndSource = dijit.tree.dndSource;
