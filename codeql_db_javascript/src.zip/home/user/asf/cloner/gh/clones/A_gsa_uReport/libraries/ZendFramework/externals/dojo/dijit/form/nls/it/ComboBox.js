({
		previousMessage: "Scelte precedenti",
		nextMessage: "Altre scelte"
})
