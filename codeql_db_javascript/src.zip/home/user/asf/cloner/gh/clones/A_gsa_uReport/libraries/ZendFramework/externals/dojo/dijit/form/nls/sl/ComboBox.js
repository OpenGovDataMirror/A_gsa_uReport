({
		previousMessage: "Prejšnje izbire",
		nextMessage: "Dodatne izbire"
})
