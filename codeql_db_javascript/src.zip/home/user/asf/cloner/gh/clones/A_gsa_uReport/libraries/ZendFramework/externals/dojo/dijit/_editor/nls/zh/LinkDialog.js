({
	createLinkTitle: "链接属性",
	insertImageTitle: "图像属性",
	url: "URL：",
	text: "描述：",
	target: "目标：",
	set: "设置",
	currentWindow: "当前窗口",
	parentWindow: "父窗口",
	topWindow: "顶层窗口",
	newWindow: "新建窗口"
})

