dojo.provide("dijit.form.RadioButton");
dojo.require("dijit.form.CheckBox");

// TODO: for 2.0, move the RadioButton code into this file
