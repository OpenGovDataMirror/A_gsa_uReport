({
		previousMessage: "Alegeri anterioare",
		nextMessage: "Mai multe alegeri"
})

