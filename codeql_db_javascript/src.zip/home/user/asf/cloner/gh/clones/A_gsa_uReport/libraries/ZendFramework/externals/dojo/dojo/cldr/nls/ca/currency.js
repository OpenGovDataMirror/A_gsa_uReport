// generated from ldml/main/*.xml, xpath: ldml/numbers/currencies
({
	AUD_displayName:"dòlar australià",
	CAD_displayName:"dòlar canadenc",
	CHF_displayName:"franc suís",
	CNY_displayName:"iuan renmimbi xinès",
	EUR_displayName:"euro",
	GBP_displayName:"lliura esterlina britànica",
	HKD_displayName:"dòlar de Hong Kong",
	JPY_displayName:"ien japonès",
	USD_displayName:"dòlar dels Estats Units"
})
                 